
---
cssclass: pinboard
---

%%---%%

<h1>OXY</h1>

![](https://storage.googleapis.com/iexcloud-hl37opg/api/logos/OXY.png)

## stockcharts

| Daily | Weekly |
|-|-
|![](https://stockcharts.com/c-sc/sc?s=OXY&p=D&b=4&g=0&i=t9270365827c&r=1650303371087)|![](https://stockcharts.com/c-sc/sc?s=OXY&p=W&b=4&g=0&i=t9270365827c&r=1650303371087)|

## WhaleWisdom

<iframe src="https://whalewisdom.com/stock/OXY" style="height:720;width:100%"></iframe>

## earningswhispers

![](https://www.earningswhispers.com/stockchart?s=OXY&amp;t=f)

## earnings estimates

<iframe src="https://www.barchart.com/stocks/quotes/OXY/earnings-estimates" width=100% height=500></iframe>

## Revenue 

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&type=revenue&statement=income-statement&freq=Q
" style="height:720;width:100%"></iframe>

## EPS

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&type=eps-earnings-per-share-diluted&statement=income-statement&freq=Q" style="height:720;width:100%"></iframe>

## Shares Outstanding

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&type=shares-outstanding&statement=income-statement&freq=Q" style="height:720;width:100%"></iframe>

## Profit Margins

<iframe src="https://www.macrotrends.net/assets/php/fundamental_metric.php?t=OXY&amp;chart=profit-margin" style="height:720;width:100%"></iframe>

## Price Ratios

### PE Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&amp;type=pe-ratio&amp;statement=price-ratios&amp;freq=Q" style="height:720;width:100%"></iframe>

### PS Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&type=price-sales&statement=price-ratios&freq=Q" style="height:720;width:100%"></iframe>

### PFCF Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&type=price-fcf&statement=price-ratios&freq=Q" style="height:720;width:100%"></iframe>

## Other Metrics

### Cash on Hand

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&type=cash-on-hand&statement=balance-sheet&freq=Q" style="height:720;width:100%"></iframe>

### Dividend Yield History

<iframe src="https://www.macrotrends.net/assets/php/dividend_yield.php?t=OXY" style="height:720;width:100%"></iframe>

### Number of Employees

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=OXY&amp;type=number-of-employees&amp;statement=&amp;freq=A" style="height:720;width:100%"></iframe>

## Dataroma 

<iframe src="https://www.dataroma.com/m/stock.php?sym=OXY" style="height:720;width:100%"></iframe>
