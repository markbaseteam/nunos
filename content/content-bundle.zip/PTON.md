
---
cssclass: pinboard
---

%%---%%

<h1>PTON</h1>

![](https://storage.googleapis.com/iexcloud-hl37opg/api/logos/PTON.png)

## stockcharts

| Daily | Weekly |
|-|-
|![](https://stockcharts.com/c-sc/sc?s=PTON&p=D&b=4&g=0&i=t9270365827c&r=1650303371087)|![](https://stockcharts.com/c-sc/sc?s=PTON&p=W&b=4&g=0&i=t9270365827c&r=1650303371087)|

## WhaleWisdom

<iframe src="https://whalewisdom.com/stock/PTON" style="height:600;width:100%"></iframe>

## earningswhispers

![](https://www.earningswhispers.com/stockchart?s=PTON&amp;t=f)

## earnings estimates

<iframe src="https://www.barchart.com/stocks/quotes/PTON/earnings-estimates" width=100% height=500></iframe>

## Revenue 

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&type=revenue&statement=income-statement&freq=Q
" style="height:720;width:100%"></iframe>

## EPS

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&type=eps-earnings-per-share-diluted&statement=income-statement&freq=Q" style="height:720;width:100%"></iframe>

## Shares Outstanding

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&type=shares-outstanding&statement=income-statement&freq=Q" style="height:720;width:100%"></iframe>

## Profit Margins

<iframe src="https://www.macrotrends.net/assets/php/fundamental_metric.php?t=PTON&amp;chart=profit-margin" style="height:720;width:100%"></iframe>

## Price Ratios

### PE Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&amp;type=pe-ratio&amp;statement=price-ratios&amp;freq=Q" style="height:720;width:100%"></iframe>

### PS Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&type=price-sales&statement=price-ratios&freq=Q" style="height:720;width:100%"></iframe>

### PFCF Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&type=price-fcf&statement=price-ratios&freq=Q" style="height:720;width:100%"></iframe>

## Other Metrics

### Cash on Hand

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&type=cash-on-hand&statement=balance-sheet&freq=Q" style="height:720;width:100%"></iframe>

### Dividend Yield History

<iframe src="https://www.macrotrends.net/assets/php/dividend_yield.php?t=PTON" style="height:720;width:100%"></iframe>

### Number of Employees

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=PTON&amp;type=number-of-employees&amp;statement=&amp;freq=A" style="height:720;width:100%"></iframe>

## Dataroma 

<iframe src="https://www.dataroma.com/m/stock.php?sym=PTON" style="height:720;width:100%"></iframe>
