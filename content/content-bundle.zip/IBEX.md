
---
cssclass: pinboard
---

%%---%%

<h1>IBEX</h1>

![](https://storage.googleapis.com/iexcloud-hl37opg/api/logos/IBEX.png)

## stockcharts

| Daily | Weekly |
|-|-
|<img src="https://stockcharts.com/c-sc/sc?s=IBEX&p=D&b=4&g=0&i=t9270365827c&r=1650303371087" style="filter: invert(1);">|<img src="https://stockcharts.com/c-sc/sc?s=IBEX&p=W&b=4&g=0&i=t9270365827c&r=1650303371087" style="filter: invert(1);">|


## WhaleWisdom

<iframe src="https://whalewisdom.com/stock/IBEX" style="height:500;width:100%;filter: invert(1);"></iframe>

## earningswhispers

<img src="https://www.earningswhispers.com/stockchart?s=IBEX&amp;t=f" style="height:500;width:100%;filter: invert(1);">

## earnings estimates

<iframe src="https://www.barchart.com/stocks/quotes/IBEX/earnings-estimates" style="height:500;width:100%;filter: invert(1);"></iframe>

## Revenue 

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&type=revenue&statement=income-statement&freq=Q
" style="height:720;width:100%;filter: invert(1);"></iframe>

## EPS

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&type=eps-earnings-per-share-diluted&statement=income-statement&freq=Q" style="height:720;width:100%;filter: invert(1);"></iframe>

## Shares Outstanding

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&type=shares-outstanding&statement=income-statement&freq=Q" style="height:720;width:100%;filter: invert(1);"></iframe>

## Profit Margins

<iframe src="https://www.macrotrends.net/assets/php/fundamental_metric.php?t=IBEX&amp;chart=profit-margin" style="height:720;width:100%;filter: invert(1);"></iframe>

## Price Ratios

### PE Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&amp;type=pe-ratio&amp;statement=price-ratios&amp;freq=Q" style="height:720;width:100%;filter: invert(1);"></iframe>

### PS Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&type=price-sales&statement=price-ratios&freq=Q" style="height:720;width:100%;filter: invert(1);"></iframe>

### PFCF Ratio

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&type=price-fcf&statement=price-ratios&freq=Q" style="height:720;width:100%;filter: invert(1);"></iframe>

## Other Metrics

### Cash on Hand

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&type=cash-on-hand&statement=balance-sheet&freq=Q" style="height:720;width:100%;filter: invert(1);"></iframe>

### Dividend Yield History

<iframe src="https://www.macrotrends.net/assets/php/dividend_yield.php?t=IBEX" style="height:720;width:100%;filter: invert(1);"></iframe>

### Number of Employees

<iframe src="https://www.macrotrends.net/assets/php/fundamental_iframe.php?t=IBEX&amp;type=number-of-employees&amp;statement=&amp;freq=A" style="height:720;width:100%;filter: invert(1);"></iframe>

## Dataroma 

<iframe src="https://www.dataroma.com/m/stock.php?sym=IBEX" style="height:720;width:100%;filter: invert(1);"></iframe>
